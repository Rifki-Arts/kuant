# Selamat Datang di Repository Quant.id

# Misi

Ini merupakan proyek non-profit yang bertujuan untuk saling sharing
strategi antar kita sesama ritel untuk meningkatkan pengetahuan,
kemampuan, dan pada akhirnya cuan kita bersama. 

Silakan Anda pakai semua yang ada di sini baik untuk kepentingan
personal maupun professional. Anda mendapatkan keuntungan trading
karena menggunakan strategi di sini, saya ikut senang. Tapi mohon
strategi atau chart dari sini jangan dijual ulang atau diikutkan 
dalam paket yang dijual, karena itu sangat tidak etis. 

Repository ini berlisensi Open Source yaitu GPL (GNU General Public 
License) versi 2 atau lebih baru. Artinya, kurang lebih, kalau Anda 
memodifikasi file-file dari sini, baik itu chart, kode, dokumentasi, 
dsb, Anda diharapkan men-share kembali hasil modifikasi Anda kepada
masyarakat secara gratis juga. Kalau semua men-share hasil penemuannya,
diharapkan tujuan proyek ini untuk meningkatkan pengetahuan, kemampuan,
dan cuan kita bersama bisa tercapai.

